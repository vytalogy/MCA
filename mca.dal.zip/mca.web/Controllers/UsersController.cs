﻿using mca.web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mca.web.Controllers
{
    public class UsersController : Controller
    {

        [HttpGet]
        //[OutputCache(Duration = 30, VaryByParam = "none")]
        public ActionResult Login()
        {
            LoginUserViewModel login = new LoginUserViewModel { };
            return View(login);
        }


        [HttpPost]
        public ActionResult Login(LoginUserViewModel login)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Home", "Products");
            }
            return View(login);
        }
    }
}