﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mca.web.Controllers
{
    public class ProductsController : Controller
    {
        // GET: Products
        public ActionResult Home()
        {
            return View();
        }

        public ActionResult Search()
        {
            return View();
        }

        public ActionResult Selector()
        {
            return View();
        }

        public ActionResult Detail()
        {
            return View();
        }

        public ActionResult Forecasting()
        {
            return View();
        }        
    }
}