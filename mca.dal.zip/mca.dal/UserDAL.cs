﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mca.dal
{
    public class UserDAL : BaseDAL
    {
        public UserDAL(String conn) : base(conn)
        {

        }

        public UserDAL()
        {

        }
        public List<mca.model.User> GetAll(Boolean? Active = null)
        {
            List<mca.model.User> _User = null;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserGetAll", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterActive = new SqlParameter("@Active", System.Data.SqlDbType.Bit);
                _SqlParameterActive.Value = Active;
                cmd.Parameters.Add(_SqlParameterActive);

                System.Data.DataSet ds = new System.Data.DataSet();
                SqlDataAdapter _SqlDataAdapter = new SqlDataAdapter(cmd);
                conn.Open();
                _SqlDataAdapter.Fill(ds);
                _User = mca.utility.Utilities.ConvertToList<mca.model.User>(ds.Tables[0]);
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return _User == null ? new List<mca.model.User>() : _User;
        }
        public List<mca.dal.UserDAL> GetAll(Roles _Role, Boolean? Active = null)
        {
            List<mca.dal.UserDAL> _User = null;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserGetAllByRoles", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterRole = new SqlParameter("@Role", System.Data.SqlDbType.VarChar);
                _SqlParameterRole.Value = _Role;
                cmd.Parameters.Add(_SqlParameterRole);


                SqlParameter _SqlParameterActive = new SqlParameter("@Active", System.Data.SqlDbType.Bit);
                if (Active == null)
                    _SqlParameterActive.Value = System.DBNull.Value;
                else
                    _SqlParameterActive.Value = Active;
                cmd.Parameters.Add(_SqlParameterActive);

                System.Data.DataSet ds = new System.Data.DataSet();
                SqlDataAdapter _SqlDataAdapter = new SqlDataAdapter(cmd);
                conn.Open();
                _SqlDataAdapter.Fill(ds);
                _User = mca.utility.ConvertToList<mca.dal.UserDAL>(ds.Tables[0]);
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return _User == null ? new List<User>() : _User;
        }
        public mca.dal.UserDAL Get(String UID, String PWD)
        {
            jessup.DAL.User _User = null;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserGet", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterUserName = new SqlParameter("@UserName", System.Data.SqlDbType.VarChar);
                _SqlParameterUserName.Value = UID;
                cmd.Parameters.Add(_SqlParameterUserName);

                SqlParameter _SqlParameterPassword = new SqlParameter("@Password", System.Data.SqlDbType.VarChar);
                _SqlParameterPassword.Value = PWD;
                cmd.Parameters.Add(_SqlParameterPassword);

                //SqlParameter _SqlParameterActive = new SqlParameter("@Active", System.Data.SqlDbType.Bit);
                //_SqlParameterActive.Value = true;
                //cmd.Parameters.Add(_SqlParameterActive);

                System.Data.DataSet ds = new System.Data.DataSet();
                SqlDataAdapter _SqlDataAdapter = new SqlDataAdapter(cmd);
                conn.Open();
                _SqlDataAdapter.Fill(ds);
                _User = com.plego.visualerp.Utility.ConvertToEntity<jessup.DAL.User>(ds.Tables[0]);
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return _User;
        }
        public mca.dal.UserDAL Get(String UID)
        {
            jessup.DAL.User _User = null;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserGetByUID", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterUserName = new SqlParameter("@UserName", System.Data.SqlDbType.VarChar);
                _SqlParameterUserName.Value = UID;
                cmd.Parameters.Add(_SqlParameterUserName);

                System.Data.DataSet ds = new System.Data.DataSet();
                SqlDataAdapter _SqlDataAdapter = new SqlDataAdapter(cmd);
                conn.Open();
                _SqlDataAdapter.Fill(ds);
                _User = com.plego.visualerp.Utility.ConvertToEntity<jessup.DAL.User>(ds.Tables[0]);
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return _User;
        }
        public mca.dal.UserDAL Get(int UserId)
        {
            jessup.DAL.User _User = null;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserGetByID", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterID = new SqlParameter("@id", System.Data.SqlDbType.Int);
                _SqlParameterID.Value = UserId;
                cmd.Parameters.Add(_SqlParameterID);

                System.Data.DataSet ds = new System.Data.DataSet();
                SqlDataAdapter _SqlDataAdapter = new SqlDataAdapter(cmd);
                conn.Open();
                _SqlDataAdapter.Fill(ds);
                _User = com.plego.visualerp.Utility.ConvertToEntity<jessup.DAL.User>(ds.Tables[0]);
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return _User;
        }
        public int Add(mca.dal.UserDAL _User)
        {
            int returnVal = -1;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserAdd", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterUserName = new SqlParameter("@UserName", System.Data.SqlDbType.VarChar);
                _SqlParameterUserName.Value = _User.UserName;
                cmd.Parameters.Add(_SqlParameterUserName);

                SqlParameter _SqlParameterEmail = new SqlParameter("@Email", System.Data.SqlDbType.VarChar);
                _SqlParameterEmail.Value = _User.Email;
                cmd.Parameters.Add(_SqlParameterEmail);

                SqlParameter _SqlParameterPassword = new SqlParameter("@Password", System.Data.SqlDbType.VarChar);
                _SqlParameterPassword.Value = _User.Password;
                cmd.Parameters.Add(_SqlParameterPassword);

                SqlParameter _SqlParameterRoles = new SqlParameter("@Roles", System.Data.SqlDbType.VarChar);
                _SqlParameterRoles.Value = _User.Roles;
                cmd.Parameters.Add(_SqlParameterRoles);

                SqlParameter _SqlParameterCreatedBy = new SqlParameter("@CreatedBy", System.Data.SqlDbType.Int);
                _SqlParameterCreatedBy.Value = _User.CreatedBy;
                cmd.Parameters.Add(_SqlParameterCreatedBy);

                SqlParameter _SqlParameterActive = new SqlParameter("@Active", System.Data.SqlDbType.Bit);
                _SqlParameterActive.Value = _User.Active;
                cmd.Parameters.Add(_SqlParameterActive);

                conn.Open();
                returnVal = Convert.ToInt16(cmd.ExecuteScalar());
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return returnVal;
        }

        public int ResetPassword(int id, String newPassword)
        {
            int returnVal = -1;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("ResetPassword", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterID = new SqlParameter("@id", System.Data.SqlDbType.Int);
                _SqlParameterID.Value = id;
                cmd.Parameters.Add(_SqlParameterID);

                SqlParameter _SqlParameterOldPassword = new SqlParameter("@OldPassword", System.Data.SqlDbType.VarChar);
                _SqlParameterOldPassword.Value = DBNull.Value;
                cmd.Parameters.Add(_SqlParameterOldPassword);

                SqlParameter _SqlParameternewPassword = new SqlParameter("@newPassword", System.Data.SqlDbType.VarChar);
                _SqlParameternewPassword.Value = newPassword;
                cmd.Parameters.Add(_SqlParameternewPassword);


                conn.Open();
                returnVal = Convert.ToInt16(cmd.ExecuteScalar());
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return returnVal;
        }
        public int ResetPassword(int id, String oldPassword, String newPassword)
        {
            int returnVal = -1;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("ResetPassword", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterID = new SqlParameter("@id", System.Data.SqlDbType.Int);
                _SqlParameterID.Value = id;
                cmd.Parameters.Add(_SqlParameterID);

                SqlParameter _SqlParameterOldPassword = new SqlParameter("@OldPassword", System.Data.SqlDbType.VarChar);
                _SqlParameterOldPassword.Value = oldPassword;
                cmd.Parameters.Add(_SqlParameterOldPassword);

                SqlParameter _SqlParameternewPassword = new SqlParameter("@newPassword", System.Data.SqlDbType.VarChar);
                _SqlParameternewPassword.Value = newPassword;
                cmd.Parameters.Add(_SqlParameternewPassword);


                conn.Open();
                returnVal = Convert.ToInt16(cmd.ExecuteScalar());
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return returnVal;
        }
        public int Update(mca.dal.UserDAL _User)
        {
            int returnVal = -1;
            SqlConnection conn = null;
            try
            {
                conn = new System.Data.SqlClient.SqlConnection(this.conn);
                SqlCommand cmd = new SqlCommand("UserUpdate", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                SqlParameter _SqlParameterID = new SqlParameter("@id", System.Data.SqlDbType.Int);
                _SqlParameterID.Value = _User.id;
                cmd.Parameters.Add(_SqlParameterID);

                //SqlParameter _SqlParameterUserName = new SqlParameter("@UserName", System.Data.SqlDbType.VarChar);
                //_SqlParameterUserName.Value = _User.UserName;
                //cmd.Parameters.Add(_SqlParameterUserName);

                //SqlParameter _SqlParameterEmail = new SqlParameter("@Email", System.Data.SqlDbType.VarChar);
                //_SqlParameterEmail.Value = _User.Email;
                //cmd.Parameters.Add(_SqlParameterEmail);

                SqlParameter _SqlParameterPassword = new SqlParameter("@Password", System.Data.SqlDbType.VarChar);
                _SqlParameterPassword.Value = _User.Password;
                cmd.Parameters.Add(_SqlParameterPassword);

                SqlParameter _SqlParameterRoles = new SqlParameter("@Roles", System.Data.SqlDbType.VarChar);
                _SqlParameterRoles.Value = _User.Roles;
                cmd.Parameters.Add(_SqlParameterRoles);

                SqlParameter _SqlParameterSecretQuestion = new SqlParameter("@SecretQuestion", System.Data.SqlDbType.VarChar);
                _SqlParameterSecretQuestion.Value = _User.SecretQuestion;
                cmd.Parameters.Add(_SqlParameterSecretQuestion);

                SqlParameter _SqlParameterSecretAnswer = new SqlParameter("@SecretAnswer", System.Data.SqlDbType.VarChar);
                _SqlParameterSecretAnswer.Value = _User.SecretAnswer;
                cmd.Parameters.Add(_SqlParameterSecretAnswer);

                SqlParameter _SqlParameterActive = new SqlParameter("@Active", System.Data.SqlDbType.Bit);
                _SqlParameterActive.Value = _User.Active;
                cmd.Parameters.Add(_SqlParameterActive);

                conn.Open();
                returnVal = Convert.ToInt16(cmd.ExecuteScalar());
                conn.Close();
            }
            catch (SqlException ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            catch (Exception ex)
            {
                DAL.Utilities.SaveException(ex);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
                conn = null;
            }
            return returnVal;
        }
    }
}
